# SCANBAY — Photo → SfM → GLB

Aplikasi web satu-file (`index.html`) yang mengubah beberapa foto sebuah objek (diambil sambil mengelilinginya) menjadi point cloud 3D lewat pipeline **incremental Structure-from-Motion**, lalu bisa diekspor sebagai `.glb`. Semuanya berjalan di browser pengguna — tidak ada server backend, tidak ada data yang diunggah ke mana pun, dan tidak ada ketergantungan API/AI apa pun.

## Cara kerja

1. **Deteksi fitur** — ORB (OpenCV.js) per foto.
2. **Matching berjendela** — setiap foto dicocokkan dengan beberapa frame tetangga (lebar jendela diatur lewat slider), bukan cuma frame berikutnya.
3. **Pembangunan track** — korespondensi antar-pasangan digabung dengan struktur *union-find* menjadi *track* multi-sudut-pandang (satu titik fisik yang teramati di beberapa foto sekaligus).
4. **Pemilihan pasangan awal** — otomatis, dipilih pasangan dengan inlier terbanyak *dan* parallax (sudut triangulasi) yang cukup, untuk menghindari inisialisasi degenerate.
5. **Registrasi inkremental** — kamera-kamera lain didaftarkan satu per satu lewat `solvePnPRansac` menggunakan korespondensi 2D–3D dari titik yang sudah tertriangulasi.
6. **Triangulasi bertahap** — titik baru ditriangulasi setiap kali kamera baru berhasil didaftarkan.
7. **Bundle adjustment (resection–intersection)** — beberapa ronde optimasi bergantian: perbaiki posisi tiap titik 3D (intersection, Gauss-Newton 3-parameter) lalu perbaiki pose tiap kamera (resection, Gauss-Newton 6-parameter), meminimalkan reprojection error secara global. Diimplementasikan murni dalam JavaScript (tanpa solver eksternal, karena OpenCV.js tidak menyediakan bundle adjustment).
8. **Pembuangan outlier** — track dengan reprojection error akhir di atas ambang (4px) dibuang.
9. **Render & ekspor** — point cloud berwarna, atau mesh perkiraan (convex hull), diekspor sebagai `.glb`.

## Kejujuran teknis tentang batasannya

- Intrinsik kamera (fokal) diasumsikan tetap dari slider FOV, **tidak** ikut dioptimasi (bukan self-calibrating bundle adjustment penuh, tidak memakai data EXIF).
- Skala keseluruhan tetap ambigu (khas SfM monokular) — baseline pasangan awal dinormalisasi ke 1 unit arbitrer.
- Bundle adjustment memakai skema **alternating resection–intersection** (refine titik lalu kamera bergantian, beberapa ronde) — metode BA yang sah dan diakui secara klasik, tapi konvergensinya lebih lambat/kurang optimal dibanding solve sparse Levenberg-Marquardt gabungan (joint) yang dipakai pipeline produksi seperti COLMAP.
- Matching dibatasi ke jendela antar-frame (bukan exhaustive penuh ke semua pasangan) demi performa di browser — bisa diperlebar lewat slider dengan konsekuensi waktu proses lebih lama.
- Hasil terbaik didapat dari foto bertekstur jelas, pencahayaan rata, dan overlap besar (~70%) antar foto berdekatan.
- Untuk kasus produksi/presisi tinggi, tetap pertimbangkan COLMAP, Meshroom, atau layanan SfM/NeRF pihak ketiga.

## Menjalankan secara lokal (sebelum deploy)

Modul ES (`<script type="module">` + import map untuk three.js) tidak bisa dibuka langsung lewat `file://` di sebagian besar browser karena pembatasan CORS. Jalankan server statis sederhana dari folder ini:

```bash
# Python (sudah terpasang di macOS/Linux)
python3 -m http.server 8000

# atau Node.js
npx serve .
```

Lalu buka `http://localhost:8000` di browser. Uji dengan mengunggah 6–20 foto, tekan **Jalankan SfM penuh**, lalu coba **Export .glb**.

Butuh koneksi internet karena Three.js dan OpenCV.js dimuat dari CDN (`cdn.jsdelivr.net` dan `docs.opencv.org`).

**Catatan soal preview di dalam Claude.ai:** panel preview artifact Claude membatasi jaringan hanya ke `cdnjs.cloudflare.com`, sehingga OpenCV.js (dihost di `docs.opencv.org`) tidak akan bisa dimuat di sana dan status akan macet di "memuat OpenCV...". Ini normal — uji selalu lewat server lokal seperti di atas atau setelah deploy ke GitHub Pages.

## Deploy ke GitHub Pages

```bash
git init
git add index.html README.md
git commit -m "Initial commit: SCANBAY full SfM pipeline"
git branch -M main
git remote add origin https://github.com/<username>/<repo>.git
git push -u origin main
```

Lalu di repo GitHub: **Settings → Pages → Source: Deploy from a branch → Branch: main / (root)**. Setelah beberapa menit, aplikasi akan tersedia di `https://<username>.github.io/<repo>/`.

## Struktur file

```
index.html   # seluruh aplikasi (UI + Three.js viewer + pipeline SfM OpenCV.js)
README.md    # dokumen ini
```
