'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { poseFrame, POSE_CONNECTIONS } from '@/lib/holo/pose-store'

export type TrackerStatus = 'idle' | 'loading' | 'running' | 'error' | 'denied'

type Options = {
  hologramMode: boolean
  showSkeleton: boolean
}

const WASM_URL = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.35/wasm'
const MODEL_URL =
  'https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/1/pose_landmarker_lite.task'

export function usePoseTracker({ hologramMode, showSkeleton }: Options) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const holoCanvasRef = useRef<HTMLCanvasElement>(null)
  const skeletonCanvasRef = useRef<HTMLCanvasElement>(null)
  const [status, setStatus] = useState<TrackerStatus>('idle')
  const [micActive, setMicActive] = useState(false)
  const streamRef = useRef<MediaStream | null>(null)
  const micStreamRef = useRef<MediaStream | null>(null)
  const rafRef = useRef<number>(0)
  const optsRef = useRef({ hologramMode, showSkeleton })
  optsRef.current = { hologramMode, showSkeleton }

  const start = useCallback(async () => {
    if (status === 'loading' || status === 'running') return
    setStatus('loading')
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' },
      })
      streamRef.current = stream
      const video = videoRef.current
      if (!video) throw new Error('video element missing')
      video.srcObject = stream
      await video.play()

      const { FilesetResolver, PoseLandmarker } = await import('@mediapipe/tasks-vision')
      const fileset = await FilesetResolver.forVisionTasks(WASM_URL)
      const landmarker = await PoseLandmarker.createFromOptions(fileset, {
        baseOptions: { modelAssetPath: MODEL_URL, delegate: 'GPU' },
        runningMode: 'VIDEO',
        numPoses: 1,
        outputSegmentationMasks: true,
      })

      setStatus('running')
      console.log('[v0] Pose landmarker ready, starting detection loop')

      let lastVideoTime = -1
      let lastFrameAt = performance.now()
      const frameCanvas = document.createElement('canvas')
      const frameCtx = frameCanvas.getContext('2d', { willReadFrequently: true })!

      const loop = () => {
        rafRef.current = requestAnimationFrame(loop)
        const v = videoRef.current
        if (!v || v.readyState < 2) return
        if (v.currentTime === lastVideoTime) return
        lastVideoTime = v.currentTime

        const now = performance.now()
        const t0 = now
        const result = landmarker.detectForVideo(v, now)
        poseFrame.inferenceMs = performance.now() - t0
        poseFrame.fps = Math.round(1000 / Math.max(1, now - lastFrameAt))
        lastFrameAt = now
        poseFrame.timestamp = now

        if (result.landmarks?.[0]) {
          poseFrame.landmarks = result.landmarks[0]
          poseFrame.worldLandmarks = result.worldLandmarks?.[0] ?? null
          poseFrame.tracking = true
        } else {
          poseFrame.tracking = false
        }

        // --- Holographic segmentation compositing ---
        const holo = holoCanvasRef.current
        if (holo) {
          const w = v.videoWidth
          const h = v.videoHeight
          if (holo.width !== w) {
            holo.width = w
            holo.height = h
            frameCanvas.width = w
            frameCanvas.height = h
          }
          const ctx = holo.getContext('2d')!
          const mask = result.segmentationMasks?.[0]
          if (optsRef.current.hologramMode && mask) {
            frameCtx.drawImage(v, 0, 0, w, h)
            const img = frameCtx.getImageData(0, 0, w, h)
            const maskData = mask.getAsFloat32Array()
            const px = img.data
            for (let i = 0; i < maskData.length; i++) {
              const j = i * 4
              if (maskData[i] < 0.4) {
                px[j + 3] = 0
              } else {
                // cyan hologram tint
                const lum = 0.299 * px[j] + 0.587 * px[j + 1] + 0.114 * px[j + 2]
                px[j] = lum * 0.35
                px[j + 1] = Math.min(255, lum * 1.05 + 40)
                px[j + 2] = Math.min(255, lum * 1.15 + 70)
              }
            }
            ctx.clearRect(0, 0, w, h)
            ctx.putImageData(img, 0, 0)
          } else {
            ctx.clearRect(0, 0, w, h)
            ctx.drawImage(v, 0, 0, w, h)
          }
          mask?.close()
        } else {
          result.segmentationMasks?.[0]?.close()
        }

        // --- Skeleton overlay ---
        const skel = skeletonCanvasRef.current
        if (skel) {
          const w = v.videoWidth
          const h = v.videoHeight
          if (skel.width !== w) {
            skel.width = w
            skel.height = h
          }
          const sctx = skel.getContext('2d')!
          sctx.clearRect(0, 0, w, h)
          const lms = poseFrame.landmarks
          if (optsRef.current.showSkeleton && lms && poseFrame.tracking) {
            sctx.strokeStyle = 'rgba(94, 234, 212, 0.9)'
            sctx.lineWidth = 2.5
            sctx.shadowColor = 'rgba(34, 211, 238, 0.9)'
            sctx.shadowBlur = 8
            for (const [a, b] of POSE_CONNECTIONS) {
              const p = lms[a]
              const q = lms[b]
              if ((p.visibility ?? 1) < 0.5 || (q.visibility ?? 1) < 0.5) continue
              sctx.beginPath()
              sctx.moveTo(p.x * w, p.y * h)
              sctx.lineTo(q.x * w, q.y * h)
              sctx.stroke()
            }
            sctx.fillStyle = 'rgba(165, 243, 252, 1)'
            for (const p of lms) {
              if ((p.visibility ?? 1) < 0.5) continue
              sctx.beginPath()
              sctx.arc(p.x * w, p.y * h, 3.5, 0, Math.PI * 2)
              sctx.fill()
            }
          }
        }
      }
      rafRef.current = requestAnimationFrame(loop)
    } catch (err) {
      console.log('[v0] Tracker failed to start:', (err as Error).message)
      const name = (err as Error).name
      setStatus(name === 'NotAllowedError' || name === 'NotFoundError' ? 'denied' : 'error')
    }
  }, [status])

  const toggleMic = useCallback(async () => {
    if (micActive) {
      micStreamRef.current?.getTracks().forEach((t) => t.stop())
      micStreamRef.current = null
      setMicActive(false)
      return
    }
    try {
      const mic = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      })
      micStreamRef.current = mic
      setMicActive(true)
    } catch {
      setMicActive(false)
    }
  }, [micActive])

  useEffect(() => {
    return () => {
      cancelAnimationFrame(rafRef.current)
      streamRef.current?.getTracks().forEach((t) => t.stop())
      micStreamRef.current?.getTracks().forEach((t) => t.stop())
    }
  }, [])

  return { videoRef, holoCanvasRef, skeletonCanvasRef, status, start, micActive, toggleMic }
}
