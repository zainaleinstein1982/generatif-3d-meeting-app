'use client'

import { Mic, MicOff, User } from 'lucide-react'

type Participant = {
  name: string
  role: string
  status: 'live' | 'idle'
  mic: boolean
}

const REMOTE_PARTICIPANTS: Participant[] = [
  { name: 'Aria Chen', role: 'Product Lead', status: 'live', mic: true },
  { name: 'Dimas Putra', role: 'Engineer', status: 'live', mic: false },
  { name: 'Sofia Reyes', role: 'Designer', status: 'idle', mic: false },
]

export function ParticipantsPanel({
  youLive,
  youMic,
}: {
  youLive: boolean
  youMic: boolean
}) {
  const all: Participant[] = [
    { name: 'You', role: 'Host', status: youLive ? 'live' : 'idle', mic: youMic },
    ...REMOTE_PARTICIPANTS,
  ]

  return (
    <ul className="flex flex-col gap-2.5">
      {all.map((p) => (
        <li key={p.name} className="flex items-center gap-3">
          <div className="relative flex size-9 shrink-0 items-center justify-center rounded-full border border-primary/30 bg-secondary">
            <User className="size-4 text-primary" aria-hidden="true" />
            <span
              className={`absolute -right-0.5 -bottom-0.5 size-2.5 rounded-full border-2 border-card ${
                p.status === 'live' ? 'animate-holo-pulse bg-primary' : 'bg-muted-foreground'
              }`}
              aria-hidden="true"
            />
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-foreground">{p.name}</p>
            <p className="truncate text-xs text-muted-foreground">{p.role}</p>
          </div>
          <span
            className={`rounded-full px-2 py-0.5 font-display text-[10px] uppercase tracking-wider ${
              p.status === 'live'
                ? 'bg-primary/15 text-primary'
                : 'bg-muted text-muted-foreground'
            }`}
          >
            {p.status === 'live' ? 'Holo' : 'Idle'}
          </span>
          {p.mic ? (
            <Mic className="size-4 text-primary" aria-label="Microphone on" />
          ) : (
            <MicOff className="size-4 text-muted-foreground" aria-label="Microphone off" />
          )}
        </li>
      ))}
    </ul>
  )
}
