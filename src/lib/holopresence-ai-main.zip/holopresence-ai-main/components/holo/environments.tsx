'use client'

import { Grid, Float, Text } from '@react-three/drei'
import * as THREE from 'three'

export type EnvironmentId =
  | 'meeting'
  | 'classroom'
  | 'auditorium'
  | 'factory'
  | 'museum'
  | 'city'

export const ENVIRONMENTS: { id: EnvironmentId; label: string; description: string }[] = [
  { id: 'meeting', label: 'Meeting Room', description: 'Virtual boardroom with holo table' },
  { id: 'classroom', label: 'Virtual Classroom', description: 'Interactive lecture space' },
  { id: 'auditorium', label: 'Auditorium', description: 'Presentation stage and seating' },
  { id: 'factory', label: 'Factory Digital Twin', description: 'Industrial twin floor' },
  { id: 'museum', label: 'Museum', description: 'Holographic exhibit hall' },
  { id: 'city', label: 'Smart City', description: 'Metaverse city plaza' },
]

function HoloFloor() {
  return (
    <Grid
      position={[0, 0, 0]}
      args={[30, 30]}
      cellSize={0.5}
      cellThickness={0.6}
      cellColor="#164e63"
      sectionSize={2.5}
      sectionThickness={1.2}
      sectionColor="#0e7490"
      fadeDistance={22}
      fadeStrength={1}
      infiniteGrid
    />
  )
}

function SceneLabel({ text }: { text: string }) {
  return (
    <Float speed={2} floatIntensity={0.3} rotationIntensity={0.1}>
      <Text
        fontSize={0.32}
        fontWeight="bold"
        position={[0, 2.6, -3]}
        color="#67e8f9"
        anchorX="center"
        anchorY="middle"
      >
        {text}
      </Text>
    </Float>
  )
}

function GlowBox({
  position,
  size,
  color = '#155e75',
  emissive = '#22d3ee',
  intensity = 0.25,
}: {
  position: [number, number, number]
  size: [number, number, number]
  color?: string
  emissive?: string
  intensity?: number
}) {
  return (
    <mesh position={position}>
      <boxGeometry args={size} />
      <meshStandardMaterial
        color={color}
        emissive={emissive}
        emissiveIntensity={intensity}
        transparent
        opacity={0.85}
      />
    </mesh>
  )
}

function MeetingRoom() {
  return (
    <group>
      <SceneLabel text="MEETING ROOM" />
      {/* Conference table */}
      <mesh position={[0, 0.72, -1.6]}>
        <cylinderGeometry args={[1.4, 1.4, 0.06, 48]} />
        <meshStandardMaterial
          color="#0c4a6e"
          emissive="#0891b2"
          emissiveIntensity={0.3}
          transparent
          opacity={0.8}
        />
      </mesh>
      <mesh position={[0, 0.36, -1.6]}>
        <cylinderGeometry args={[0.12, 0.3, 0.72, 24]} />
        <meshStandardMaterial color="#1e293b" />
      </mesh>
      {/* Chairs around the table */}
      {Array.from({ length: 6 }).map((_, i) => {
        const a = (i / 6) * Math.PI * 2
        return (
          <GlowBox
            key={i}
            position={[Math.cos(a) * 2.1, 0.4, -1.6 + Math.sin(a) * 2.1]}
            size={[0.45, 0.8, 0.45]}
            intensity={0.12}
          />
        )
      })}
      {/* Screen wall */}
      <GlowBox position={[0, 1.6, -5]} size={[4.5, 2.2, 0.08]} color="#082f49" intensity={0.4} />
    </group>
  )
}

function Classroom() {
  return (
    <group>
      <SceneLabel text="VIRTUAL CLASSROOM" />
      <GlowBox position={[0, 1.4, -4.5]} size={[5, 2, 0.08]} color="#082f49" intensity={0.45} />
      {Array.from({ length: 3 }).map((_, row) =>
        Array.from({ length: 4 }).map((_, col) => (
          <GlowBox
            key={`${row}-${col}`}
            position={[(col - 1.5) * 1.4, 0.4, 0.5 + row * 1.3]}
            size={[0.9, 0.7, 0.5]}
            intensity={0.1}
          />
        )),
      )}
    </group>
  )
}

function Auditorium() {
  return (
    <group>
      <SceneLabel text="AUDITORIUM" />
      {/* Stage */}
      <mesh position={[0, 0.15, -1]}>
        <cylinderGeometry args={[3, 3.3, 0.3, 64, 1, false, 0, Math.PI]} />
        <meshStandardMaterial color="#0c4a6e" emissive="#0891b2" emissiveIntensity={0.25} />
      </mesh>
      {/* Tiered seating arcs */}
      {[4.5, 5.8, 7.1].map((r, tier) =>
        Array.from({ length: 9 }).map((_, i) => {
          const a = Math.PI * 0.15 + (i / 8) * Math.PI * 0.7
          return (
            <GlowBox
              key={`${tier}-${i}`}
              position={[Math.cos(a) * r, 0.3 + tier * 0.35, Math.sin(a) * r]}
              size={[0.5, 0.5, 0.5]}
              intensity={0.08}
            />
          )
        }),
      )}
      <pointLight color="#a855f7" intensity={3} distance={8} position={[0, 4, -1]} />
    </group>
  )
}

function Factory() {
  return (
    <group>
      <SceneLabel text="FACTORY DIGITAL TWIN" />
      {/* Machine rows */}
      {Array.from({ length: 3 }).map((_, i) => (
        <group key={i} position={[-3.5 + i * 3.5, 0, -3]}>
          <GlowBox position={[0, 0.75, 0]} size={[1.6, 1.5, 1.2]} color="#134e4a" emissive="#2dd4bf" intensity={0.2} />
          <GlowBox position={[0, 1.8, 0]} size={[0.3, 0.6, 0.3]} color="#1e293b" intensity={0.05} />
        </group>
      ))}
      {/* Conveyor */}
      <GlowBox position={[0, 0.35, -0.8]} size={[9, 0.1, 0.8]} color="#0f172a" emissive="#22d3ee" intensity={0.3} />
      {/* Pipes */}
      <mesh position={[0, 2.6, -3]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.1, 0.1, 10, 12]} />
        <meshStandardMaterial color="#334155" emissive="#0891b2" emissiveIntensity={0.15} />
      </mesh>
    </group>
  )
}

function Museum() {
  return (
    <group>
      <SceneLabel text="HOLOGRAPHIC MUSEUM" />
      {[-3, 0, 3].map((x, i) => (
        <group key={i} position={[x, 0, -2.5]}>
          <mesh position={[0, 0.5, 0]}>
            <cylinderGeometry args={[0.45, 0.55, 1, 24]} />
            <meshStandardMaterial color="#1e1b4b" emissive="#6366f1" emissiveIntensity={0.2} />
          </mesh>
          <Float speed={2.5} floatIntensity={0.6} rotationIntensity={2}>
            <mesh position={[0, 1.6, 0]}>
              {i === 0 ? (
                <icosahedronGeometry args={[0.35, 0]} />
              ) : i === 1 ? (
                <torusKnotGeometry args={[0.25, 0.08, 64, 12]} />
              ) : (
                <octahedronGeometry args={[0.35, 0]} />
              )}
              <meshStandardMaterial
                color="#22d3ee"
                emissive="#22d3ee"
                emissiveIntensity={0.6}
                wireframe
              />
            </mesh>
          </Float>
        </group>
      ))}
    </group>
  )
}

function SmartCity() {
  const buildings = [
    [-4, 2.2, -5],
    [-2.2, 3.4, -6.5],
    [0, 4.2, -8],
    [2.4, 2.8, -6],
    [4.2, 3.6, -5.5],
    [-5.5, 1.6, -3],
    [5.5, 2, -3.5],
  ] as const
  return (
    <group>
      <SceneLabel text="SMART CITY PLAZA" />
      {buildings.map(([x, h, z], i) => (
        <mesh key={i} position={[x, h / 2, z]}>
          <boxGeometry args={[1.1, h, 1.1]} />
          <meshStandardMaterial
            color="#0f172a"
            emissive={i % 2 ? '#22d3ee' : '#818cf8'}
            emissiveIntensity={0.25}
            transparent
            opacity={0.9}
          />
        </mesh>
      ))}
      {/* Data streams */}
      {buildings.slice(0, 4).map(([x, h, z], i) => (
        <mesh key={`beam-${i}`} position={[x, h + 1, z]}>
          <cylinderGeometry args={[0.02, 0.02, 2, 6]} />
          <meshBasicMaterial color="#67e8f9" transparent opacity={0.5} blending={THREE.AdditiveBlending} />
        </mesh>
      ))}
    </group>
  )
}

export function HoloEnvironment({ env }: { env: EnvironmentId }) {
  return (
    <group>
      <HoloFloor />
      <ambientLight intensity={0.35} />
      <directionalLight position={[4, 6, 3]} intensity={0.6} color="#bae6fd" />
      <fog attach="fog" args={['#0a0e1a', 8, 26]} />
      {env === 'meeting' && <MeetingRoom />}
      {env === 'classroom' && <Classroom />}
      {env === 'auditorium' && <Auditorium />}
      {env === 'factory' && <Factory />}
      {env === 'museum' && <Museum />}
      {env === 'city' && <SmartCity />}
    </group>
  )
}
