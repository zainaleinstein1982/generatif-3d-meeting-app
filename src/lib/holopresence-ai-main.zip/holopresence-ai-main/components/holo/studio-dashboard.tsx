'use client'

import { useCallback, useRef, useState } from 'react'
import Link from 'next/link'
import {
  Bone,
  Camera,
  ChevronLeft,
  Circle,
  Loader2,
  Mic,
  MicOff,
  Sparkles,
  Square,
  Users,
  Video,
} from 'lucide-react'
import { usePoseTracker } from './use-pose-tracker'
import { SceneViewport } from './scene-viewport'
import { StatsPanel } from './stats-panel'
import { ParticipantsPanel } from './participants-panel'
import { ENVIRONMENTS, type EnvironmentId } from './environments'

function PanelHeader({ title, badge }: { title: string; badge?: string }) {
  return (
    <div className="mb-3 flex items-center justify-between">
      <h2 className="font-display text-xs uppercase tracking-[0.2em] text-primary">{title}</h2>
      {badge ? (
        <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[10px] uppercase tracking-wider text-primary">
          {badge}
        </span>
      ) : null}
    </div>
  )
}

export function StudioDashboard() {
  const [hologramMode, setHologramMode] = useState(true)
  const [showSkeleton, setShowSkeleton] = useState(true)
  const [env, setEnv] = useState<EnvironmentId>('meeting')
  const [recording, setRecording] = useState(false)
  const glCanvasRef = useRef<HTMLCanvasElement | null>(null)
  const recorderRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])

  const { videoRef, holoCanvasRef, skeletonCanvasRef, status, start, micActive, toggleMic } =
    usePoseTracker({ hologramMode, showSkeleton })

  const takeScreenshot = useCallback(() => {
    const canvas = glCanvasRef.current
    if (!canvas) return
    const a = document.createElement('a')
    a.href = canvas.toDataURL('image/png')
    a.download = `holopresence-${Date.now()}.png`
    a.click()
  }, [])

  const toggleRecording = useCallback(() => {
    if (recording) {
      recorderRef.current?.stop()
      setRecording(false)
      return
    }
    const canvas = glCanvasRef.current
    if (!canvas) return
    const stream = canvas.captureStream(30)
    const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' })
    chunksRef.current = []
    recorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunksRef.current.push(e.data)
    }
    recorder.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: 'video/webm' })
      const a = document.createElement('a')
      a.href = URL.createObjectURL(blob)
      a.download = `holopresence-session-${Date.now()}.webm`
      a.click()
      URL.revokeObjectURL(a.href)
    }
    recorder.start()
    recorderRef.current = recorder
    setRecording(true)
  }, [recording])

  const live = status === 'running'

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Top bar */}
      <header className="glass sticky top-0 z-20 flex items-center gap-3 px-4 py-3">
        <Link
          href="/"
          className="flex items-center gap-1 rounded-lg px-2 py-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ChevronLeft className="size-4" aria-hidden="true" />
          <span className="sr-only sm:not-sr-only">Home</span>
        </Link>
        <h1 className="font-display text-sm tracking-[0.25em] text-foreground neon-text">
          HOLOPRESENCE <span className="text-primary">AI</span>
        </h1>
        <span
          className={`ml-auto flex items-center gap-1.5 rounded-full px-3 py-1 text-xs ${
            live ? 'bg-primary/15 text-primary' : 'bg-muted text-muted-foreground'
          }`}
        >
          <span
            className={`size-2 rounded-full ${live ? 'animate-holo-pulse bg-primary' : 'bg-muted-foreground'}`}
            aria-hidden="true"
          />
          {live ? 'LIVE' : 'OFFLINE'}
        </span>
      </header>

      <main className="grid flex-1 gap-4 p-4 lg:grid-cols-[minmax(0,1fr)_320px]">
        {/* Left column: 3D scene + camera strip */}
        <div className="flex min-w-0 flex-col gap-4">
          {/* 3D viewport */}
          <section
            aria-label="3D holographic scene"
            className="glass scanlines relative h-[46vh] min-h-72 overflow-hidden rounded-2xl neon-glow lg:h-[56vh]"
          >
            <SceneViewport env={env} onCanvasReady={(c) => (glCanvasRef.current = c)} />
            {!live && (
              <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-4 bg-background/70 backdrop-blur-sm">
                <p className="max-w-xs text-center text-sm text-pretty text-muted-foreground">
                  {status === 'denied'
                    ? 'Camera access was denied. Allow camera permissions and try again.'
                    : status === 'error'
                      ? 'Failed to initialize the AI engine. Please retry.'
                      : 'Start your camera to project your volumetric avatar into the scene.'}
                </p>
                <button
                  type="button"
                  onClick={start}
                  disabled={status === 'loading'}
                  className="flex items-center gap-2 rounded-xl bg-primary px-6 py-3 font-display text-sm tracking-wider text-primary-foreground transition-transform hover:scale-105 disabled:opacity-60"
                >
                  {status === 'loading' ? (
                    <>
                      <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                      INITIALIZING AI
                    </>
                  ) : (
                    <>
                      <Video className="size-4" aria-hidden="true" />
                      START TELEPORTATION
                    </>
                  )}
                </button>
              </div>
            )}
            {/* Teleport selector */}
            <div className="absolute top-3 left-3 z-10 flex max-w-full flex-wrap gap-1.5 pr-3">
              {ENVIRONMENTS.map((e) => (
                <button
                  key={e.id}
                  type="button"
                  onClick={() => setEnv(e.id)}
                  title={e.description}
                  className={`rounded-full px-3 py-1 text-[11px] tracking-wide transition-colors ${
                    env === e.id
                      ? 'bg-primary text-primary-foreground'
                      : 'glass text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {e.label}
                </button>
              ))}
            </div>
            {recording && (
              <div className="absolute top-3 right-3 z-10 flex items-center gap-1.5 rounded-full bg-destructive/20 px-3 py-1 text-xs text-destructive">
                <span className="size-2 animate-holo-pulse rounded-full bg-destructive" aria-hidden="true" />
                REC
              </div>
            )}
          </section>

          {/* Control bar */}
          <div className="glass flex flex-wrap items-center justify-center gap-2 rounded-2xl p-2.5">
            <button
              type="button"
              onClick={toggleMic}
              className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm transition-colors ${
                micActive ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground hover:bg-muted'
              }`}
            >
              {micActive ? <Mic className="size-4" aria-hidden="true" /> : <MicOff className="size-4" aria-hidden="true" />}
              {micActive ? 'Mic On' : 'Mic Off'}
            </button>
            <button
              type="button"
              onClick={() => setHologramMode((v) => !v)}
              className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm transition-colors ${
                hologramMode ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground hover:bg-muted'
              }`}
            >
              <Sparkles className="size-4" aria-hidden="true" />
              Hologram
            </button>
            <button
              type="button"
              onClick={() => setShowSkeleton((v) => !v)}
              className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm transition-colors ${
                showSkeleton ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground hover:bg-muted'
              }`}
            >
              <Bone className="size-4" aria-hidden="true" />
              Skeleton
            </button>
            <button
              type="button"
              onClick={toggleRecording}
              disabled={!live}
              className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm transition-colors disabled:opacity-50 ${
                recording ? 'bg-destructive text-white' : 'bg-secondary text-secondary-foreground hover:bg-muted'
              }`}
            >
              {recording ? <Square className="size-4" aria-hidden="true" /> : <Circle className="size-4" aria-hidden="true" />}
              {recording ? 'Stop' : 'Record'}
            </button>
            <button
              type="button"
              onClick={takeScreenshot}
              disabled={!live}
              className="flex items-center gap-2 rounded-xl bg-secondary px-4 py-2.5 text-sm text-secondary-foreground transition-colors hover:bg-muted disabled:opacity-50"
            >
              <Camera className="size-4" aria-hidden="true" />
              Screenshot
            </button>
          </div>

          {/* Camera feeds */}
          <div className="grid gap-4 sm:grid-cols-2">
            <section aria-label="Live camera with AI segmentation" className="glass scanlines relative overflow-hidden rounded-2xl p-3">
              <PanelHeader title="Live Capture" badge={hologramMode ? 'AI Segmented' : 'Raw'} />
              <div className="relative aspect-video overflow-hidden rounded-xl bg-background">
                {/* Hidden source video; canvases render the processed output */}
                <video ref={videoRef} playsInline muted className="absolute size-0 opacity-0" aria-hidden="true" />
                <canvas ref={holoCanvasRef} className="absolute inset-0 size-full -scale-x-100 object-cover" />
                {!live && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Video className="size-8 text-muted-foreground/40" aria-hidden="true" />
                  </div>
                )}
              </div>
            </section>
            <section aria-label="AI pose skeleton" className="glass scanlines relative overflow-hidden rounded-2xl p-3">
              <PanelHeader title="AI Skeleton" badge="BlazePose 33pt" />
              <div className="relative aspect-video overflow-hidden rounded-xl bg-background">
                <canvas ref={skeletonCanvasRef} className="absolute inset-0 size-full -scale-x-100 object-cover" />
                {!live && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Bone className="size-8 text-muted-foreground/40" aria-hidden="true" />
                  </div>
                )}
              </div>
            </section>
          </div>
        </div>

        {/* Right column: participants + stats */}
        <aside className="flex flex-col gap-4">
          <section aria-label="Participants" className="glass rounded-2xl p-4">
            <PanelHeader title="Participants" badge="4 in session" />
            <ParticipantsPanel youLive={live} youMic={micActive} />
            <p className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground">
              <Users className="size-3.5" aria-hidden="true" />
              Multi-user presence via WebRTC mesh
            </p>
          </section>
          <section aria-label="Performance monitor" className="glass rounded-2xl p-4">
            <PanelHeader title="Performance" badge={live ? 'Realtime' : 'Standby'} />
            <StatsPanel />
          </section>
          <section aria-label="Pipeline status" className="glass rounded-2xl p-4">
            <PanelHeader title="AI Pipeline" />
            <ul className="flex flex-col gap-2 text-xs text-muted-foreground">
              {[
                ['Pose Estimation', 'BlazePose GHUM'],
                ['Segmentation', 'Neural Matting'],
                ['Reconstruction', 'Volumetric Splat'],
                ['Streaming', 'WebRTC / 30fps'],
              ].map(([stage, engine]) => (
                <li key={stage} className="flex items-center justify-between">
                  <span>{stage}</span>
                  <span className={`font-display text-[10px] tracking-wider ${live ? 'text-primary' : ''}`}>
                    {engine}
                  </span>
                </li>
              ))}
            </ul>
          </section>
        </aside>
      </main>
    </div>
  )
}
