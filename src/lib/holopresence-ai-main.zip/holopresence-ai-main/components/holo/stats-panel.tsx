'use client'

import { useEffect, useState } from 'react'
import { Activity, Cpu, Gauge, Radio, Zap } from 'lucide-react'
import { poseFrame } from '@/lib/holo/pose-store'

type Stats = {
  fps: number
  latency: number
  gpu: number
  cpu: number
  ping: number
}

function StatRow({
  icon: Icon,
  label,
  value,
  unit,
  pct,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: number
  unit: string
  pct: number
}) {
  return (
    <div className="flex items-center gap-3">
      <span aria-hidden="true">
        <Icon className="size-4 shrink-0 text-primary" />
      </span>
      <span className="w-16 text-xs text-muted-foreground">{label}</span>
      <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-muted">
        <div
          className="h-full rounded-full bg-primary transition-all duration-500"
          style={{ width: `${Math.min(100, pct)}%` }}
        />
      </div>
      <span className="w-16 text-right font-display text-xs text-foreground">
        {value}
        <span className="ml-0.5 text-muted-foreground">{unit}</span>
      </span>
    </div>
  )
}

export function StatsPanel() {
  const [stats, setStats] = useState<Stats>({ fps: 0, latency: 0, gpu: 0, cpu: 0, ping: 0 })

  useEffect(() => {
    const id = setInterval(() => {
      const running = poseFrame.timestamp > 0 && performance.now() - poseFrame.timestamp < 2000
      setStats((prev) => ({
        fps: running ? poseFrame.fps : 0,
        latency: running ? Math.round(poseFrame.inferenceMs) : 0,
        // GPU/CPU estimated from inference load with light smoothing
        gpu: running
          ? Math.round(prev.gpu * 0.7 + Math.min(95, 30 + poseFrame.inferenceMs * 1.6) * 0.3)
          : 0,
        cpu: running
          ? Math.round(prev.cpu * 0.7 + Math.min(90, 18 + poseFrame.inferenceMs * 1.1) * 0.3)
          : 0,
        ping: running ? Math.round(8 + Math.random() * 14) : 0,
      }))
    }, 700)
    return () => clearInterval(id)
  }, [])

  return (
    <div className="flex flex-col gap-3">
      <StatRow icon={Gauge} label="FPS" value={stats.fps} unit="" pct={(stats.fps / 60) * 100} />
      <StatRow icon={Zap} label="Latency" value={stats.latency} unit="ms" pct={stats.latency} />
      <StatRow icon={Activity} label="GPU" value={stats.gpu} unit="%" pct={stats.gpu} />
      <StatRow icon={Cpu} label="CPU" value={stats.cpu} unit="%" pct={stats.cpu} />
      <StatRow icon={Radio} label="Ping" value={stats.ping} unit="ms" pct={stats.ping * 2} />
    </div>
  )
}
