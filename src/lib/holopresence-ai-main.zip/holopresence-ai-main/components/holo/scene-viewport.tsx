'use client'

import { Canvas } from '@react-three/fiber'
import { OrbitControls, Stars } from '@react-three/drei'
import { HoloAvatar } from './holo-avatar'
import { HoloEnvironment, type EnvironmentId } from './environments'

export function SceneViewport({
  env,
  onCanvasReady,
}: {
  env: EnvironmentId
  onCanvasReady?: (canvas: HTMLCanvasElement) => void
}) {
  return (
    <Canvas
      camera={{ position: [0, 1.6, 3.4], fov: 55 }}
      gl={{ preserveDrawingBuffer: true, antialias: true }}
      onCreated={(state) => {
        state.gl.setClearColor('#0a0e1a')
        onCanvasReady?.(state.gl.domElement)
      }}
      className="!absolute inset-0"
    >
      <Stars radius={60} depth={40} count={1500} factor={3} saturation={0.4} fade speed={0.6} />
      <HoloEnvironment env={env} />
      <HoloAvatar position={[0, 0, 0]} />
      <OrbitControls
        enablePan={false}
        minDistance={1.5}
        maxDistance={10}
        maxPolarAngle={Math.PI / 2.05}
        target={[0, 1, 0]}
      />
    </Canvas>
  )
}
