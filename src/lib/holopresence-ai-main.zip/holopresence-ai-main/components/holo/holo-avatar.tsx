'use client'

import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { poseFrame, POSE_CONNECTIONS } from '@/lib/holo/pose-store'

const JOINT_COUNT = 33
const PARTICLES_PER_BONE = 14

/**
 * Real-time volumetric holographic avatar.
 * Joints (instanced spheres) + bones (line segments) + a shimmering
 * particle shell are driven every frame from MediaPipe world landmarks.
 */
export function HoloAvatar({ position = [0, 0, 0] as [number, number, number] }) {
  const jointsRef = useRef<THREE.InstancedMesh>(null)
  const linesRef = useRef<THREE.LineSegments>(null)
  const particlesRef = useRef<THREE.Points>(null)
  const groupRef = useRef<THREE.Group>(null)
  const dummy = useMemo(() => new THREE.Object3D(), [])

  const lineGeometry = useMemo(() => {
    const geo = new THREE.BufferGeometry()
    geo.setAttribute(
      'position',
      new THREE.BufferAttribute(new Float32Array(POSE_CONNECTIONS.length * 2 * 3), 3),
    )
    return geo
  }, [])

  const particleGeometry = useMemo(() => {
    const count = POSE_CONNECTIONS.length * PARTICLES_PER_BONE
    const geo = new THREE.BufferGeometry()
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(count * 3), 3))
    return geo
  }, [])

  useFrame((state) => {
    const world = poseFrame.worldLandmarks
    const tracking = poseFrame.tracking
    const g = groupRef.current
    if (g) {
      // Gentle holographic float + fade when no tracking
      g.position.y = position[1] + Math.sin(state.clock.elapsedTime * 1.2) * 0.02
      g.visible = Boolean(tracking && world)
    }
    if (!world || !tracking) return

    // MediaPipe world coords: meters, y-down → flip y, mirror x
    const toVec = (i: number) =>
      new THREE.Vector3(-world[i].x, -world[i].y + 1.0, -world[i].z)

    const joints = jointsRef.current
    if (joints) {
      for (let i = 0; i < JOINT_COUNT; i++) {
        const p = toVec(i)
        dummy.position.copy(p)
        const s = i === 0 ? 2.2 : i < 11 ? 0.9 : 1.4
        dummy.scale.setScalar(s)
        dummy.updateMatrix()
        joints.setMatrixAt(i, dummy.matrix)
      }
      joints.instanceMatrix.needsUpdate = true
    }

    const lines = linesRef.current
    if (lines) {
      const arr = lines.geometry.attributes.position.array as Float32Array
      POSE_CONNECTIONS.forEach(([a, b], k) => {
        const pa = toVec(a)
        const pb = toVec(b)
        arr[k * 6] = pa.x
        arr[k * 6 + 1] = pa.y
        arr[k * 6 + 2] = pa.z
        arr[k * 6 + 3] = pb.x
        arr[k * 6 + 4] = pb.y
        arr[k * 6 + 5] = pb.z
      })
      lines.geometry.attributes.position.needsUpdate = true
    }

    const particles = particlesRef.current
    if (particles) {
      const arr = particles.geometry.attributes.position.array as Float32Array
      const t = state.clock.elapsedTime
      let idx = 0
      POSE_CONNECTIONS.forEach(([a, b], k) => {
        const pa = toVec(a)
        const pb = toVec(b)
        for (let i = 0; i < PARTICLES_PER_BONE; i++) {
          const f = i / PARTICLES_PER_BONE
          const jitter = 0.025
          arr[idx++] = pa.x + (pb.x - pa.x) * f + Math.sin(t * 3 + k * 7 + i) * jitter
          arr[idx++] = pa.y + (pb.y - pa.y) * f + Math.cos(t * 2.4 + k * 3 + i) * jitter
          arr[idx++] = pa.z + (pb.z - pa.z) * f + Math.sin(t * 2.8 + k * 5 + i * 2) * jitter
        }
      })
      particles.geometry.attributes.position.needsUpdate = true
    }
  })

  return (
    <group ref={groupRef} position={position}>
      <instancedMesh ref={jointsRef} args={[undefined, undefined, JOINT_COUNT]} frustumCulled={false}>
        <sphereGeometry args={[0.022, 12, 12]} />
        <meshBasicMaterial color="#7df9ff" transparent opacity={0.95} />
      </instancedMesh>
      <lineSegments ref={linesRef} geometry={lineGeometry} frustumCulled={false}>
        <lineBasicMaterial color="#22d3ee" transparent opacity={0.85} />
      </lineSegments>
      <points ref={particlesRef} geometry={particleGeometry} frustumCulled={false}>
        <pointsMaterial
          color="#a5f3fc"
          size={0.014}
          transparent
          opacity={0.7}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
        />
      </points>
      {/* Ground projection ring */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 0]}>
        <ringGeometry args={[0.28, 0.42, 48]} />
        <meshBasicMaterial
          color="#22d3ee"
          transparent
          opacity={0.35}
          side={THREE.DoubleSide}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
        />
      </mesh>
      <pointLight color="#22d3ee" intensity={2} distance={3} position={[0, 1.2, 0]} />
    </group>
  )
}
