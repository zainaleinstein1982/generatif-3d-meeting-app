import type { Metadata } from 'next'
import { StudioDashboard } from '@/components/holo/studio-dashboard'

export const metadata: Metadata = {
  title: 'Holo Studio — HoloPresence AI',
  description:
    'Live volumetric capture studio: AI pose tracking, holographic avatar, and virtual teleportation.',
}

export default function StudioPage() {
  return <StudioDashboard />
}
