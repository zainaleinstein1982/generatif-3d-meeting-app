import Link from 'next/link'
import {
  ArrowRight,
  Bone,
  Box,
  Factory,
  Mic,
  ScanFace,
  Sparkles,
  Users,
  Video,
} from 'lucide-react'

const FEATURES = [
  {
    icon: ScanFace,
    title: 'AI Human Detection',
    description: 'Face, hands, body, and full pose tracked in real time from a single RGB webcam.',
  },
  {
    icon: Bone,
    title: '33-Point Pose Estimation',
    description: 'BlazePose GHUM skeleton drives your avatar with sub-frame latency, fully on-device.',
  },
  {
    icon: Sparkles,
    title: 'Volumetric Avatar',
    description: 'A shimmering holographic reconstruction mirrors your movement in full 3D space.',
  },
  {
    icon: Video,
    title: 'AI Background Removal',
    description: 'Neural segmentation cuts you out of any room — no green screen required.',
  },
  {
    icon: Box,
    title: 'Teleport Anywhere',
    description: 'Beam into meeting rooms, classrooms, auditoriums, museums, and smart cities.',
  },
  {
    icon: Factory,
    title: 'Digital Twin Ready',
    description: 'Project your presence into factory floors and industrial twin environments.',
  },
  {
    icon: Users,
    title: 'Multi-User Presence',
    description: 'WebRTC-powered sessions place multiple holographic participants in one scene.',
  },
  {
    icon: Mic,
    title: 'Spatial Voice',
    description: 'Echo-cancelled, noise-suppressed audio streaming built on native WebRTC.',
  },
]

export default function HomePage() {
  return (
    <main className="relative min-h-screen overflow-hidden bg-background">
      {/* Ambient glow backdrops */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-40 left-1/2 size-[600px] -translate-x-1/2 rounded-full bg-primary/10 blur-3xl"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-1/2 -right-40 size-96 rounded-full bg-accent/10 blur-3xl"
      />

      <header className="relative z-10 mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <p className="font-display text-sm tracking-[0.3em] text-foreground neon-text">
          HOLOPRESENCE <span className="text-primary">AI</span>
        </p>
        <Link
          href="/studio"
          className="glass rounded-xl px-4 py-2 text-sm text-foreground transition-colors hover:text-primary"
        >
          Launch Studio
        </Link>
      </header>

      <section className="relative z-10 mx-auto flex max-w-4xl flex-col items-center px-6 pt-16 pb-20 text-center md:pt-24">
        <span className="glass mb-6 rounded-full px-4 py-1.5 text-xs tracking-widest text-primary uppercase">
          Real-Time Volumetric Teleportation
        </span>
        <h1 className="font-display text-4xl leading-tight text-balance text-foreground md:text-6xl">
          Be there, <span className="text-primary neon-text">without being there.</span>
        </h1>
        <p className="mt-6 max-w-2xl text-base leading-relaxed text-pretty text-muted-foreground md:text-lg">
          HoloPresence AI reconstructs you as a living hologram from a single webcam — then
          teleports your volumetric avatar into virtual meeting rooms, classrooms, digital twins,
          and metaverse spaces. All in your browser, powered by on-device AI.
        </p>
        <div className="mt-10 flex flex-col items-center gap-4 sm:flex-row">
          <Link
            href="/studio"
            className="neon-glow flex items-center gap-2 rounded-xl bg-primary px-8 py-4 font-display text-sm tracking-wider text-primary-foreground transition-transform hover:scale-105"
          >
            START TELEPORTING
            <ArrowRight className="size-4" aria-hidden="true" />
          </Link>
          <p className="text-xs text-muted-foreground">Webcam required · Runs 100% in-browser</p>
        </div>

        {/* Hologram mock frame */}
        <div className="glass scanlines relative mt-16 w-full max-w-3xl overflow-hidden rounded-2xl p-6 neon-glow">
          <div className="grid grid-cols-3 gap-3 text-left">
            {[
              ['POSE', 'Tracking'],
              ['MESH', 'Reconstructing'],
              ['SCENE', 'Teleporting'],
            ].map(([label, state]) => (
              <div key={label} className="rounded-xl bg-background/60 p-4">
                <p className="font-display text-[10px] tracking-[0.25em] text-primary">{label}</p>
                <p className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                  <span className="size-1.5 animate-holo-pulse rounded-full bg-primary" aria-hidden="true" />
                  {state}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section aria-label="Features" className="relative z-10 mx-auto max-w-6xl px-6 pb-24">
        <h2 className="mb-10 text-center font-display text-xl tracking-widest text-foreground uppercase">
          The Pipeline
        </h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f) => (
            <article key={f.title} className="glass rounded-2xl p-5 transition-transform hover:-translate-y-1">
              <f.icon className="size-6 text-primary" aria-hidden="true" />
              <h3 className="mt-4 text-sm font-semibold text-foreground">{f.title}</h3>
              <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{f.description}</p>
            </article>
          ))}
        </div>
      </section>

      <footer className="relative z-10 border-t border-border py-8 text-center text-xs text-muted-foreground">
        HoloPresence AI — volumetric telepresence in the browser
      </footer>
    </main>
  )
}
